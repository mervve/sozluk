package com.example.sozluk;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Parser extends AppCompatActivity {
    private RecyclerView rv;
    private CardAdapter3 adapter3;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.parser_design);

        ArrayList<String> array = (ArrayList<String>) getIntent().getSerializableExtra("array");

        rv= findViewById(R.id.rv3);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(this));
        array= Parsing(array);

        adapter3= new CardAdapter3(this,array);
        rv.setAdapter(adapter3);
    }

    private ArrayList<String> Parsing(ArrayList<String> array){

        ArrayList<String> array2 = new ArrayList<String>();
        String[] str;
        str=array.get(0).split(" ");
        for(int i=0; i<str.length;i++){

            array2.add(str[i]);
        }


        return array2;
    }


}
